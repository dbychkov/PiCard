#include "ts.h"
#include <string.h>
#include <Arduino.h>

TS::TS(){reset();};

void __not_in_flash_func (TS::reset)()
{
     memset(reg[0], 0, 16);     
     memset(reg[1], 0, 16);
};

void __not_in_flash_func (TS::select_reg)(uint8_t N_reg)
{
    if (N_reg == 0xff) {i_chip = 0;return;} 
    if (N_reg == 0xfe) {i_chip = 1;return;}
    if (N_reg>0x0f) return;
    i_reg[i_chip]=N_reg;
};

uint8_t  __not_in_flash_func (TS::get_reg)()
{
    return reg[i_chip][i_reg[i_chip]];
};


uint8_t maskREG[16] = {0xff,0x0f,0xff,0x0f,0xff,0x0f ,0x1f, 0xff, 0x1f,0x1f,0x1f, 0xff , 0xff, 0x0f,0xff,0xff};
void __not_in_flash_func (TS::set_reg)(uint8_t val)
{
    if (i_reg[i_chip]>0x0f) return;

    reg[i_chip][i_reg[i_chip]] = val & maskREG[i_reg[i_chip]];
//    switch (N_sel_reg)
//        {
//        case 6:  // частота генератора шума 	0 - 31
//            noise_ay0_count = 0;
//            return;
//        case 13://Выбор формы волнового пакета 	0 - 15
//            is_envelope_begin = true;
//            return;
//        }
    
};

TS ts;


         #if TS_EN
                  if ((addr16&0xc003)==(0xfffd&0xc003)) ay.select_reg(d8);
                  if ((addr16&0xc003)==(0xbffd&0xc003)) ay.set_reg(d8);
                #endif

         #if TS_EN
                    if ((addr16&0xc003)==(0xfffd&0xc003)) put_dataZ80(ay.get_reg());
                #endif


