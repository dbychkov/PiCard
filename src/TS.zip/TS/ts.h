#pragma once
#include "inttypes.h"


class TS {
private:
    int i_chip=0;
    uint8_t i_reg[2];
    uint8_t reg[2][16];

public:

    TS();
//    void chip_select(uint i_chip);
    void reset();
    void select_reg(uint8_t N_reg);
    uint8_t  get_reg();
    void set_reg(uint8_t val);


    
};

extern TS ts;
